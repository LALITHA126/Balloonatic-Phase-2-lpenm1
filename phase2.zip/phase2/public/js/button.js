function myFunction() {
    window.location.assign("/");
}

function myProduct() {
    window.location.assign("product");
}

function myAbout() {
    window.location.assign("about");
}

function myContact() {
    window.location.assign("contact");
}
function loginPage() {
    window.location.assign("login");
}
function registerPage() {
    window.location.assign("register");
}
function logoutPage() {
    window.location.assign("logout");
}